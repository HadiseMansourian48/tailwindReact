import React from "react";

function Aa(){
    return(
        <>
        <div className="bg-red-50 border-4 border-blue-500 text-blue-700 rounded p-4">
      <p className="font-bold bg-red-50">Info</p>
            <p className="">This is a simple alert box</p>
        </div></>
    )
}

export default Aa